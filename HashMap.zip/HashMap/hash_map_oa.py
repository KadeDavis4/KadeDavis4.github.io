from include import (DynamicArray, DynamicArrayException, HashEntry,
                        hash_function_1, hash_function_2)


class HashMap:
    def __init__(self, capacity: int, function) -> None:
        """
        Initialize new HashMap that uses
        quadratic probing for collision resolution
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self._buckets = DynamicArray()

        # capacity must be a prime number
        self._capacity = self._next_prime(capacity)
        for _ in range(self._capacity):
            self._buckets.append(None)

        self._hash_function = function
        self._size = 0

    def __str__(self) -> str:
        """
        Override string method to provide more readable output
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        out = ''
        for i in range(self._buckets.length()):
            out += str(i) + ': ' + str(self._buckets[i]) + '\n'
        return out

    def _next_prime(self, capacity: int) -> int:
        """
        Increment from given number to find the closest prime number
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        if capacity % 2 == 0:
            capacity += 1

        while not self._is_prime(capacity):
            capacity += 2

        return capacity

    @staticmethod
    def _is_prime(capacity: int) -> bool:
        """
        Determine if given integer is a prime number and return boolean
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        if capacity == 2 or capacity == 3:
            return True

        if capacity == 1 or capacity % 2 == 0:
            return False

        factor = 3
        while factor ** 2 <= capacity:
            if capacity % factor == 0:
                return False
            factor += 2

        return True

    def get_size(self) -> int:
        """
        Return size of map
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._size

    def get_capacity(self) -> int:
        """
        Return capacity of map
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._capacity

    # ------------------------------------------------------------------ #

    def put(self, key: str, value: object) -> None:
        """
        Inserts has entry into hash table
        """
        if self.table_load() >= 0.5:
            self.resize_table(self._capacity * 2)

        index = self._hash_function(key) % self._capacity
        i_initial = index

        inserted = None
        j = 1
        while not inserted:
            node_at_index = self._buckets.get_at_index(index)
            if (node_at_index is None) or (node_at_index.is_tombstone is True):
                self._buckets.set_at_index(index, HashEntry(key, value))
                inserted = True
                self._size += 1
            elif node_at_index.key == key:
                node_at_index.value = value
                inserted = True
            else:
                index = (i_initial + (j*j)) % self._capacity
                j += 1
        
            

        

    def resize_table(self, new_capacity: int) -> None:
        """
        Resizes table to entered capacity or next prime of entered capacity
        """
        if new_capacity < self._size:
            return
        
        key_values = self.get_keys_and_values()
        
        new_capacity = self._next_prime(new_capacity)
        self._capacity = new_capacity

        self._buckets = DynamicArray()
        for i in range (new_capacity):
            self._buckets.append(None)
        self._size = 0

        for i in range(key_values.length()):
            self.put(key_values.get_at_index(i)[0], key_values.get_at_index(i)[1])

    def table_load(self) -> float:
        """
        Returns hashmap load factor
        """
        return (self._size / self._buckets.length())

    def empty_buckets(self) -> int:
        """
        Returns number of empty buckets in hashmap
        """
        empty = 0
        for i in range(self._capacity):
            node_at_index = self._buckets.get_at_index(i)
            if (node_at_index is None) or (node_at_index.is_tombstone is True):
                empty += 1
        return empty

    def get(self, key: str) -> object:
        """
        Returns value of item with entered key, or none if item does not exist
        """
        complete = None
        j = 1
        index = self._hash_function(key) % self._capacity
        i_initial = index
        while not complete:
            node_at_index = self._buckets.get_at_index(index)
            if (node_at_index is None):
                return None
            if (node_at_index.key == key) and (node_at_index.is_tombstone is False):
                return node_at_index.value
            index = (i_initial + (j*j)) % self._capacity
            j += 1
                

    def contains_key(self, key: str) -> bool:
        """
        Returns true if item with key is in hashmap, and false if not
        """
        complete = None
        j = 1
        index = self._hash_function(key) % self._capacity
        i_initial = index
        while not complete:
            node_at_index = self._buckets.get_at_index(index)
            if (node_at_index is None):
                return False
            if (node_at_index.key == key) and (node_at_index.is_tombstone == False):
                return True
            index = (i_initial + j*j) % self._capacity
            j += 1

    def remove(self, key: str) -> None:
        """
        Removes item with entered key and replaces it with tombstone
        """
        if self.contains_key(key) is False:
            return
        else:
            complete = None
            j = 1
            index = self._hash_function(key) % self._capacity
            i_initial = index
            while not complete:
                node_at_index = self._buckets.get_at_index(index)
                if (node_at_index.key == key):
                    node_at_index.is_tombstone = True
                    self._size -= 1
                    return
                index = (i_initial + j*j) % self._capacity
                j += 1

    def get_keys_and_values(self) -> DynamicArray:
        """
        Returns an array with all keys and values in hashmap
        """
        array = DynamicArray()

        for i in range(self._capacity):
            node_at_index = self._buckets.get_at_index(i)
            if (node_at_index is None) or (node_at_index.is_tombstone is True):
                continue
            else:
                array.append((node_at_index.key, node_at_index.value))
        return array


    def clear(self) -> None:
        """
        Clears hashmap while retaining capacity
        """
        self._buckets = DynamicArray()
        for i in range (self._capacity):
            self._buckets.append(None)
        self._size = 0

    def __iter__(self):
        """
        Initializes hashmap iterator
        """
        self._iter_index = 0
        return self

    def __next__(self):
        """
        Iterates once on interator and returns value
        """
        self._iter_index += 1
        if self._iter_index >= self._capacity:
                raise StopIteration
        while self._buckets.get_at_index(self._iter_index) is None:
            self._iter_index += 1
            if self._iter_index >= self._capacity:
                raise StopIteration
        return self._buckets.get_at_index(self._iter_index)