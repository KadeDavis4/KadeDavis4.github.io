from include import (DynamicArray, LinkedList,
                        hash_function_1, hash_function_2)


class HashMap:
    def __init__(self,
                 capacity: int = 11,
                 function: callable = hash_function_1) -> None:
        """
        Initialize new HashMap that uses
        separate chaining for collision resolution
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        self._buckets = DynamicArray()

        # capacity must be a prime number
        self._capacity = self._next_prime(capacity)
        for _ in range(self._capacity):
            self._buckets.append(LinkedList())

        self._hash_function = function
        self._size = 0

    def __str__(self) -> str:
        """
        Override string method to provide more readable output
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        out = ''
        for i in range(self._buckets.length()):
            out += str(i) + ': ' + str(self._buckets[i]) + '\n'
        return out

    def _next_prime(self, capacity: int) -> int:
        """
        Increment from given number and the find the closest prime number
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        if capacity % 2 == 0:
            capacity += 1

        while not self._is_prime(capacity):
            capacity += 2

        return capacity

    @staticmethod
    def _is_prime(capacity: int) -> bool:
        """
        Determine if given integer is a prime number and return boolean
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        if capacity == 2 or capacity == 3:
            return True

        if capacity == 1 or capacity % 2 == 0:
            return False

        factor = 3
        while factor ** 2 <= capacity:
            if capacity % factor == 0:
                return False
            factor += 2

        return True

    def get_size(self) -> int:
        """
        Return size of map
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._size

    def get_capacity(self) -> int:
        """
        Return capacity of map
        DO NOT CHANGE THIS METHOD IN ANY WAY
        """
        return self._capacity

    # ------------------------------------------------------------------ #

    def put(self, key: str, value: object) -> None:
        """
        Inserts key value pair into correct bucket in hash map 
        """
        if self.table_load() >= 1.0:
            self.resize_table(self._buckets.length() * 2)
        
        target_bucket = self._buckets.get_at_index(self._hash_function(key) % self._buckets.length())

        if target_bucket.contains(key) is None:
            target_bucket.insert(key, value)
            self._size = self._size + 1
        else:
            target_bucket.contains(key).value = value

    def resize_table(self, new_capacity: int) -> None:
        """
        Stores key value pairs, resets hash map with new capacity, and reinsterts key value pairs
        """
        if new_capacity < 1:
            return
        
        if self._is_prime(new_capacity) == False:
            new_capacity = self._next_prime(new_capacity)
 
        key_values = self.get_keys_and_values()
        
        self._buckets = DynamicArray()
        for _ in range(new_capacity):
            self._buckets.append(LinkedList())
        self._capacity = new_capacity
        self._size = 0

        for i in range (key_values.length()):
            self.put(key_values.get_at_index(i)[0], key_values.get_at_index(i)[1])
        


    def table_load(self) -> float:
        """
        Returns table load factor
        """
        return (self._size / self._buckets.length())

    def empty_buckets(self) -> int:
        """
        Returns the number of empty buckets in hash map
        """
        value = 0
        for i in range (self._buckets.length()):
            if self._buckets.get_at_index(i).length() == 0:
                value += 1
        return value

    def get(self, key: str) -> object:
        """
        Returns node with given key, or None if it does not exist
        """
        target_bucket = self._buckets.get_at_index(self._hash_function(key) % self._buckets.length())
        if target_bucket.contains(key) is not None:
            return target_bucket.contains(key).value
        else:
            return None

    def contains_key(self, key: str) -> bool:
        """
        Returns True if key is in hashmap and False if it is not
        """
        target_bucket = self._buckets.get_at_index(self._hash_function(key) % self._buckets.length())
        if target_bucket.contains(key) is None:
            return False
        else:
            return True

    def remove(self, key: str) -> None:
        """
        Removes node with specified key
        """
        if self.contains_key(key) is False:
            return
        
        target_bucket = self._buckets.get_at_index(self._hash_function(key) % self._buckets.length())
        target_bucket.remove(key)
        self._size = self._size - 1

    def get_keys_and_values(self) -> DynamicArray:
        """
        Returns dynamic array of all self key value pairs in tuples
        """
        array = DynamicArray()

        for i in range (self._buckets.length()):
            if self._buckets.get_at_index(i).length() > 0:
                iterator = self._buckets.get_at_index(i).__iter__()
                node = iterator.__next__()
                array.append((node.key, node.value))
                while node.next is not None:
                    node = iterator.__next__()
                    array.append((node.key, node.value))
        return array

    def clear(self) -> None:
        """
        Clears all buckets and retains capactiy
        """
        new_da = DynamicArray()
        for i in range (self._capacity):
            new_da.append(LinkedList())
        self._buckets = new_da
        self._size = 0


def find_mode(da: DynamicArray) -> tuple[DynamicArray, int]:
    """
    Returns a tuple containing a dynamic array of the mode(s) and an integer representing the frequency
    """
    map = HashMap(da.length())
    for i in range(da.length()):
        value = da.get_at_index(i)
        if map.contains_key(value):
            frequency = map.get(value)
            frequency += 1
            map.put(value, frequency)
        else:
            map.put(value, 1)
    
    values = map.get_keys_and_values()
    frequency = 0
    modes = DynamicArray()
    for i in range(values.length()):
        if values.get_at_index(i)[1] > frequency:
            frequency = values.get_at_index(i)[1]
            modes = DynamicArray()
            modes.append(values.get_at_index(i)[0])
        elif values.get_at_index(i)[1] == frequency:
            modes.append(values.get_at_index(i)[0])
    return (modes, frequency)
