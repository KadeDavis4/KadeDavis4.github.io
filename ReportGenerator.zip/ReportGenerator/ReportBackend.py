import pandas as pd
import matplotlib.pyplot as plot
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt
from docx.shared import Inches


def load_data(filepath):
    """Load csv file as dataframe"""
    df = pd.read_csv(filepath)
    return df

def validate_inputs(df, group_col, metric_cols):
    """Check group_col and metric_cols actually exist in df, 
    check metric_cols are numeric. Raise or return errors."""
    if df.empty:
        return False

    if group_col not in df.columns:
        return False

    for col in metric_cols:
        if col not in df.columns:
            return False
        if not pd.api.types.is_numeric_dtype(df[col]):
            return False

    return True

def aggregate_data(df, group_col, metric_cols):
    """Groupby + Aggregation"""
    return df.groupby(group_col)[metric_cols].mean().reset_index()


def get_extremes(agg_df, metric_col, top_n=3):
    """Return top N and bottom N groups for one metric"""
    bottom = agg_df.sort_values(metric_col).head(top_n)
    top = agg_df.sort_values(metric_col).tail(top_n)
    return top, bottom

def generate_chart(agg_df, group_col, metric_col, chart_type):
    """Build matplotlib chart, save to a path, return that path"""
    figure, axes = plot.subplots()

    if chart_type == 'Vertical Bar':
        sorted_df = agg_df.sort_values(metric_col, ascending=False)
        axes.bar(sorted_df[group_col], sorted_df[metric_col])
    elif chart_type == "Line":
        sorted_df = agg_df.sort_values(metric_col, ascending=False)
        axes.plot(sorted_df[group_col], sorted_df[metric_col])
    else:
        sorted_df = agg_df.sort_values(metric_col, ascending=False)
        axes.barh(sorted_df[group_col], sorted_df[metric_col])
    if (chart_type == 'Vertical Bar') or (chart_type == "Line"):
        axes.set_xlabel(f"{group_col}")
        axes.set_ylabel(f"{metric_col}")
        plot.setp(axes.get_xticklabels(), rotation=45, ha='right')
    else:
        axes.set_xlabel(f"{metric_col}")
        axes.set_ylabel(f"{group_col}")

    path = f"{metric_col}_chart.png"
    figure.tight_layout()
    figure.savefig(f"{metric_col}_chart.png")
    plot.close(figure)
    return path

def generate_narrative(agg_df, group_col, metric_cols, top_n=3):
    """Loop metrics, build f-string sentences, return list of strings"""
    narrative = []
    for metric in metric_cols:
        top, bottom = get_extremes(agg_df, metric, top_n)
        top_group = top[group_col].iloc[top_n - 1]
        top_val = round(top[metric].iloc[top_n - 1], 2)
        bottom_val = round(bottom[metric].iloc[0], 2)
        bottom_group = bottom[group_col].iloc[0]

        Sentence = f"The top {metric} in the data is {top_group} at {top_val}, wheras {bottom_val} is the lowest at {bottom_group}"
        narrative.append(Sentence)
    return narrative

def build_report(agg_df, metric_cols, group_col, title, include_table, include_chart, chart_type, output_path):
    """Assemble the docx from all the pieces above"""
    doc = Document()

    if title == "":
        title = "Report"

    heading = doc.add_heading(title, level=1)
    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER 
    heading.runs[0].font.size = Pt(28)
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(12)

    doc.add_paragraph("")

    if include_table:
        table = doc.add_table(rows=1, cols=len(metric_cols)+1)
        table.style = 'Table Grid'

        hdr_cells = table.rows[0].cells

        columns = [group_col] + metric_cols
        for i, col_name in enumerate(columns):
            hdr_cells[i].text = col_name
        for _, row in agg_df.iterrows():
            row_cells = table.add_row().cells
            for i, col_name in enumerate(columns):
                if isinstance(row[col_name], float):
                    row[col_name] = round(row[col_name], 2)
                row_cells[i].text = str(row[col_name])

    chart_paths = []
    if include_chart:
        for metric in metric_cols:
            path = generate_chart(agg_df, group_col, metric, chart_type)
            chart_paths.append(path)

    narratives = generate_narrative(agg_df, group_col, metric_cols, 1)

    doc.add_paragraph("")

    for i, metric in enumerate(metric_cols):
        doc.add_heading(metric, level=2)
        if include_chart:
            doc.add_picture(chart_paths[i], width=Inches(4.5))
        doc.add_paragraph(narratives[i])

    print(f"Saving to {output_path}")
    doc.save(f"{output_path}/{title}.docx")
