import ReportBackend
import os
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
import pandas as pd
from pathlib import Path

#Windows
def confirmation_window(name):
    confirmwndow = tk.Toplevel(window)
    confirmwndow.title("Success")
    confirmwndow.geometry("400x100")

    if outputpath == ".":
        savedto = os.getcwd()
        openpath = ""
    else:
        savedto = outputpath
        openpath = f"{outputpath}/"

    if name == "":
        name = "Report"

    confirmlabel = tk.Label(confirmwndow, text=f"Report Successfully Saved to\n{savedto}/", font=18)
    confirmlabel.pack(pady=10)

    openbutton = tk.Button(confirmwndow, text="Open Report", command=lambda: open_report(f"{openpath}{name}.docx", confirmwndow))
    openbutton.pack()

def choose_group(csv):
    csvwindow = tk.Toplevel(window)
    csvwindow.title("Choose Group")
    csvwindow.geometry("500x150")

    group_label = tk.Label(csvwindow, text="Choose group to aggregate data on", font=("Arial", 16))
    group_label.pack(pady=15)

    df = ReportBackend.load_data(csv)
    columns = df.columns
    group_columns = [col for col in columns if type(col) is str]

    global group_var
    group_var = tk.StringVar()
    group_dropdown = ttk.Combobox(csvwindow, textvariable=group_var, values=group_columns, state='readonly', font=("Arial", 16))
    group_var.set(group_columns[0])
    group_dropdown.pack()

    sumbit_group = tk.Button(csvwindow, text="Select", font=("Arial", 16), command=lambda: select_group(csv, csvwindow))
    sumbit_group.pack(pady=5)

def choose_metrics(csv):
    metricswindow = tk.Toplevel(window)
    metricswindow.title("Choose Metrics")
    metricswindow.geometry("300x450")

    metrics_label = tk.Label(metricswindow, text="Choose metrics to apply", font=("Arial", 16))
    metrics_label.pack(pady=15)

    df = ReportBackend.load_data(csv)
    columns = list(df.columns)

    metric_columns = [col for col in columns if pd.api.types.is_numeric_dtype(df[col]) and col != group_var.get()]

    metric_vars = {}
    for col in metric_columns:
        var = tk.BooleanVar()
        metric_vars[col] = var
        check = tk.Checkbutton(metricswindow, text=col, variable=var)
        check.pack(anchor='w')

    submit_button = tk.Button(metricswindow, text="Select", font=("Arial", 16), command=lambda: submit_metrics(metric_vars, metricswindow))
    submit_button.pack(pady=10)







#Program Run function
def run_program(csv_path, group, metrics, name, include_table, include_chart, chart_type, output_path):
    name_error.config(text="")

    if not validate_name(name):
        name_error.config(text="Invalid Windows File Name")
        return

    if csv_path is None:
        csv_error.config(text="Please Select a csv File")
        return

    if not metrics:
        csv_error.config(text="Please Select Metric(s)")
        return
    
    df = ReportBackend.load_data(csv_path)
    agg_df = ReportBackend.aggregate_data(df, group, metrics)
    ReportBackend.build_report(agg_df, metrics, group, name, include_table, include_chart, chart_type, output_path)
    confirmation_window(name)
    csv_error.config(text="")

#Helper functions
def submit_metrics(metric_vars, metricswindow):
    global metrics
    metrics = [col for col in metric_vars if metric_vars[col].get()]
    metricswindow.destroy()

def select_group(csv, windowtoclose):
    windowtoclose.destroy()
    choose_metrics(csv)

def open_report(path, close_window):
    os.startfile(path)
    close_window.destroy()

def browse_file():
    global filepath
    chosen = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    chosen_path = Path(chosen)
    csv_error.config(text=chosen_path.name)
    try:
        testdf = ReportBackend.load_data(chosen)
        if len(testdf.columns) < 2:
            csv_error.config(text="csv only has 1 column or incorrect formatting")
            return
    except:
        csv_error.config(text="Please Select a csv File")
        return
    filepath = chosen
    choose_group(filepath)


def choose_output():
    global outputpath
    chosen = filedialog.askdirectory()
    if chosen:
        outputpath = chosen

def validate_name(unchecked_name):
        reserved = {"CON", "PRN", "AUX", "NUL",
                "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
                "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"}

        if unchecked_name.upper().split('.')[0] in reserved:
            return False

        unusable = '<>:"/\\|?*'
        for character in unchecked_name:
            if character in unusable:
                return False

        if unchecked_name.endswith(' ') or unchecked_name.endswith('.'):
            return False

        return True






    


#GUI
window = tk.Tk()
window.geometry("500x550")
window.title("Report Generator")

title = tk.Label(window, text="Report Generator", font=("Arial", 24))
title.pack(pady=(20, 10))

file_frame = tk.LabelFrame(window, text="Data & Output", padx=15, pady=10)
file_frame.pack(fill="x", padx=20, pady=10)

filepath = None
csv_button = tk.Button(file_frame, text="Choose CSV", width=20, command=browse_file)
csv_button.grid(row=0, column=0, sticky="w", pady=5)

csv_error = tk.Label(file_frame, text="")
csv_error.grid(row=0, column=1, sticky="w", padx=(10, 0))

outputpath = "."
output_button = tk.Button(file_frame, text="Choose Output Path", width=20, command=choose_output)
output_button.grid(row=1, column=0, sticky="w", pady=5)

tk.Label(file_frame, text="Report Title:").grid(row=2, column=0, sticky="w", pady=(10, 0))
title_entry = tk.Entry(file_frame, width=30)
title_entry.grid(row=3, column=0, sticky="w", pady=(0, 5))

name_error = tk.Label(file_frame, text="")
name_error.grid(row=3, column=1, sticky="w", padx=(10, 0))

options_frame = tk.LabelFrame(window, text="Report Options", padx=15, pady=10)
options_frame.pack(fill="x", padx=20, pady=10)

include_table = tk.BooleanVar(value=True)
include_chart = tk.BooleanVar(value=True)

table_check = tk.Checkbutton(options_frame, text="Include Table", variable=include_table)
table_check.grid(row=0, column=0, sticky="w")

chart_check = tk.Checkbutton(options_frame, text="Include Chart", variable=include_chart)
chart_check.grid(row=1, column=0, sticky="w")

tk.Label(options_frame, text="Chart Type:").grid(row=2, column=0, sticky="w", pady=(10, 0))
chart_type_dropdown = ttk.Combobox(options_frame, width=20, values=['Horizontal Bar', 'Vertical Bar', 'Line', ], state='readonly')
chart_type_dropdown.set('Horizontal Bar')
chart_type_dropdown.grid(row=3, column=0, sticky="w", pady=(0, 5))

group_var = tk.StringVar()
metrics = None
button1 = tk.Button(window, text="Generate Report", font=("Arial", 16), width=25, command=lambda: run_program(filepath, group_var.get(), metrics, title_entry.get(), include_table.get(), include_chart.get(), chart_type_dropdown.get(), outputpath))
button1.pack(pady=20)







#Run
if __name__ == "__main__":


    window.mainloop()