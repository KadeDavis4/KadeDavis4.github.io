// Get an instance of mysql we can use in the app
const mysql = require("mysql2");

// Create a 'connection pool' using the provided credentials
const pool = mysql.createPool({
    waitForConnections: true,
    connectionLimit: 10,
    host: '[Removed for privacy]',
    user: '[Removed for privacy]',
    password: '[Removed for privacy]', 
    database: '[Removed for privacy]'
}).promise();

// Export it for use in our application
module.exports = pool;